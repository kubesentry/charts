# KubeSentry Helm Chart

Self-hosted Kubernetes threat detection. This chart deploys:

- **Falco** (subchart) as a DaemonSet on every node, with Falcosidekick forwarding
  events to the collector's webhook.
- **KubeSentry collector** — a single-replica Deployment that ingests Falco events,
  deduplicates and stores them in SQLite, serves the dashboard, and sends
  notifications.
- **Supporting resources** — Service, PVC (optional), ConfigMap of curated rules,
  Secrets for the license and notification credentials, a ServiceAccount, and a
  Helm test Pod.

The dashboard is **unauthenticated** — reach it via `kubectl port-forward` (or put
your own auth proxy / Ingress in front of it).

## Prerequisites

- Kubernetes 1.25+ (kind, k3s, EKS, GKE, AKS — anything conformant)
- Helm 3.8+
- A node OS that supports Falco's `modern_ebpf` driver (most recent kernels). For
  older kernels, override `falco.driver.kind`.

## Quick start

> Install with the release name **`kubesentry`**. The Falco subchart forwards
> events to the Service named `kubesentry-collector`, which the chart only produces
> when the release name is `kubesentry`. (See *Troubleshooting* if you must use a
> different name.)

```sh
helm repo add falcosecurity https://falcosecurity.github.io/charts
helm dependency build deploy/helm/kubesentry

helm install kubesentry deploy/helm/kubesentry \
  --namespace kubesentry --create-namespace \
  --set cluster.name=prod-us-east
```

This runs in **trial mode** (7 days) until you add a license.

## License setup

Start on the trial, then upgrade in place with your license JWT:

```sh
helm upgrade kubesentry deploy/helm/kubesentry \
  --namespace kubesentry \
  --reuse-values \
  --set license="eyJhbGciOiJFZERTQSI..."
```

The chart stores it in a Secret and injects it as `LICENSE_KEY`. The collector
validates it **offline** (no license server). When a license is expired or
invalid, the dashboard and rules keep working but notifications are disabled.

## Notifications setup

All channels are optional and off by default. **For production, prefer
`existingSecret`** over inline values so credentials never sit in your Helm
release values.

### Email (Resend)

```yaml
notifications:
  email:
    enabled: true
    from: "alerts@mail.kubesentry.io"
    to: ["security@example.com"]
    existingSecret: "kubesentry-email"   # Secret with key: resend-api-key
```

Inline (testing only): set `resendApiKey` instead of `existingSecret`.

### Slack / Discord / Teams

```yaml
notifications:
  slack:
    enabled: true
    existingSecret: "kubesentry-slack"   # Secret with key: slack-webhook-url
  discord:
    enabled: true
    webhookUrl: "https://discord.com/api/webhooks/..."   # inline (testing)
  teams:
    enabled: true
    existingSecret: "kubesentry-teams"   # Secret with key: teams-webhook-url
```

Expected `existingSecret` keys: `resend-api-key`, `slack-webhook-url`,
`discord-webhook-url`, `teams-webhook-url`.

### Daily digest

```yaml
digest:
  enabled: true
  cron: "0 9 * * *"
  timezone: "Europe/Zagreb"
```

The digest is email-only; it is a no-op unless email is configured.

## Configuration reference

| Key | Default | Description |
| --- | --- | --- |
| `falco.enabled` | `true` | Deploy the Falco subchart |
| `falco.driver.kind` | `modern_ebpf` | Falco driver; override for older kernels |
| `collector.image.repository` | `ghcr.io/kubesentry/collector` | Collector image |
| `collector.image.tag` | `0.7.0` | Image tag |
| `collector.image.pullPolicy` | `IfNotPresent` | Image pull policy |
| `collector.resources` | 100m/128Mi → 500m/512Mi | Requests/limits |
| `collector.persistence.enabled` | `true` | Use a PVC for the SQLite DB |
| `collector.persistence.size` | `1Gi` | PVC size |
| `collector.persistence.storageClass` | `""` | Storage class (empty = cluster default) |
| `license` | `""` | License JWT; empty = 7-day trial |
| `cluster.name` | `default` | Cluster label in dashboard/emails/webhooks |
| `notifications.email.*` | disabled | Resend email config |
| `notifications.slack.*` | disabled | Slack webhook config |
| `notifications.discord.*` | disabled | Discord webhook config |
| `notifications.teams.*` | disabled | Teams webhook config |
| `digest.enabled` | `true` | Daily digest email |
| `digest.cron` | `0 9 * * *` | Digest schedule |
| `digest.timezone` | `UTC` | Digest timezone |
| `dashboard.url` | `""` | Public dashboard URL (used in links) |
| `service.type` | `ClusterIP` | Collector Service type |
| `service.port` | `8080` | Collector Service port |
| `serviceAccount.create` | `true` | Create a ServiceAccount |

## Upgrade

```sh
helm dependency build deploy/helm/kubesentry
helm upgrade kubesentry deploy/helm/kubesentry \
  --namespace kubesentry --reuse-values
```

The SQLite DB persists across upgrades when `collector.persistence.enabled=true`.

## Uninstall

```sh
helm uninstall kubesentry --namespace kubesentry
```

PVCs are not removed automatically — delete them if you want to discard history:

```sh
kubectl -n kubesentry delete pvc -l app.kubernetes.io/name=kubesentry
```

## Troubleshooting

1. **No alerts in the dashboard.** Check Falcosidekick can reach the collector:
   the webhook address is `http://kubesentry-collector:8080/webhook/falco`. This
   resolves only when the release name is `kubesentry`. If you used a different
   name, set `falco.falcosidekick.config.webhook.address` to your actual Service
   name (`<release>-kubesentry-collector`).
2. **Collector CrashLoopBackOff with a DB error.** The DB lives at `/data`
   (`DATA_DIR`). With `persistence.enabled=true` that's the PVC; ensure your
   storage class supports `ReadWriteOnce` and the `fsGroup` (65532) can write.
3. **Falco pods won't start.** The `modern_ebpf` driver needs a recent kernel.
   Try `--set falco.driver.kind=ebpf` or `kmod`.
4. **Notifications never fire.** Confirm the license is valid (`kubectl logs` shows
   `License: licensed …`); an expired/invalid license disables notifications. Also
   confirm the channel is `enabled` and its Secret key name matches.
5. **`helm install` fails on the Falco dependency.** Run
   `helm repo add falcosecurity https://falcosecurity.github.io/charts` and
   `helm dependency build deploy/helm/kubesentry` first.
6. **Dashboard shows a red/yellow banner.** Yellow = trial countdown; red =
   expired/invalid license. Add or renew the license via `helm upgrade --set license=…`.
