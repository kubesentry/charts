{{/*
Expand the name of the chart.
*/}}
{{- define "kubesentry.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
Truncated at 63 chars (Kubernetes name limit).
*/}}
{{- define "kubesentry.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Chart name and version, for the helm.sh/chart label.
*/}}
{{- define "kubesentry.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels.
*/}}
{{- define "kubesentry.labels" -}}
helm.sh/chart: {{ include "kubesentry.chart" . }}
{{ include "kubesentry.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels.
*/}}
{{- define "kubesentry.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubesentry.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
ServiceAccount name to use.
*/}}
{{- define "kubesentry.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
{{- default (include "kubesentry.fullname" .) .Values.serviceAccount.name -}}
{{- else -}}
{{- default "default" .Values.serviceAccount.name -}}
{{- end -}}
{{- end -}}

{{/*
Name of the inline notifications Secret (holds resendApiKey + webhook URLs that
were set inline, i.e. not via a per-channel existingSecret).
*/}}
{{- define "kubesentry.notificationsSecretName" -}}
{{- printf "%s-notifications" (include "kubesentry.fullname" .) -}}
{{- end -}}
